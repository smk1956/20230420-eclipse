package com.example.D;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DApplicationTests {

	@Test
	void contextLoads() {
	}

}
