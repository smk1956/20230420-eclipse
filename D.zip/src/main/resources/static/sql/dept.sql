use koritd;

create table group_d_dept(
group_d_dept_code char(3) not null,
group_d_dept_name varchar(20) not null,
primary key(group_d_dept_code)
);

INSERT INTO group_d_dept VALUES('100', '신입회원');
INSERT INTO group_d_dept VALUES('200', '준회원');
INSERT INTO group_d_dept VALUES('300', '정회원');
INSERT INTO group_d_dept VALUES('900', '관리자');

CREATE TABLE group_d_pos(
group_d_pos_code char(3) not null,
group_d_pos_name varchar(20) not null,
group_d_dept_code char(3),
primary key(group_d_pos_code),
foreign key(group_d_dept_code) references group_d_dept(group_d_dept_code)
ON UPDATE CASCADE ON DELETE RESTRICT
);

INSERT INTO group_d_pos VALUES('101', '신입회원', '100');
INSERT INTO group_d_pos VALUES('201', '준회원', '200');
INSERT INTO group_d_pos VALUES('301', '정회원', '300');
INSERT INTO group_d_pos VALUES('901', '관리자', '900');

SELECT D.group_d_dept_name, P.group_d_pos_name FROM
group_d_dept D INNER JOIN group_d_pos P ON
D.group_d_dept_code = P.group_d_dept_code;