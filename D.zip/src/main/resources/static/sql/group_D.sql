use koritd;

CREATE TABLE group_d(
d_val int not null auto_increment,
d_id varchar(50) not null unique,
d_passwd varchar(20) not null,
d_name varchar(50) not null,
d_email varchar(50) not null unique,
d_auth char(1),
d_created datetime,
d_modified datetime,
primary key(d_val)
);

INSERT INTO group_d VALUES(NULL, '111','111', '관리자', 'mail@mail.com', 'Y', now(), now());