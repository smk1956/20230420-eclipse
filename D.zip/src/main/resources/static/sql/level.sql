use koritd;

create table group_d_level(
group_d_level_code int,
group_d_level_name varchar(20)
);
INSERT INTO group_d_level VALUES(7, "Level 7");
INSERT INTO group_d_level VALUES(3, "Level 3");
INSERT INTO group_d_level VALUES(2, "Level 2");
INSERT INTO group_d_level VALUES(1, "Level 1");
