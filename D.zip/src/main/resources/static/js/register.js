function frmcheck() {
          let dId = document.querySelector(".dId");
          let dName = document.querySelector(".dName");
          let dPwd = document.querySelector(".dPwd");
          let dEmail = document.querySelector(".dEmail");

          if (!dId.value) {
            alert("아이디를 입력해 주세요.");
            dId.focus();
            return false;
          }

          if (!dPwd.value) {
            alert("비밀번호를 입력해 주세요.");
            dPwd.focus();
            return false;
          }

          if (!dName.value) {
            alert("이름를 입력해 주세요.");
            dName.focus();
            return false;
          }

          if (!dEmail.value) {
            alert("이메일를 입력해 주세요.");
            dEmail.focus();
            return false;
          }

          let obj = {
            dId: dId.value,
            dName: dName.value,
            dPwd: dPwd.value,
            dEmail:dEmail.value,
          };

          $.ajax({
            type: "post",
            url: "/register",
            dataType: "json",
            data: obj,
            success: function (res) {
              if (res.msg == "success") {
                alert("회원가입이 완료 되었습니다.");
                location.href = "/login";
              }
            },
          });


        }
function btncheck(){
  location.href = "/login";
}