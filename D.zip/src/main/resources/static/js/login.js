let btn = document.querySelector(".btn");
    let dId = document.querySelector(".dId");
    let dPwd = document.querySelector(".dPwd");

    btn.addEventListener('click', function(e){
      e.preventDefault();

      if(!dId.value){
        alert("아이디를 입력 하세요.");
        dId.focus();
        return false;
      }

      if(!dPwd.value){
        alert("비밀번호를 입력 하세요.");
        dPwd.focus();
        return false;
      }

      $.ajax({
        type: "post",
        url: "/login",
        dataType: "json",
        data: {dId : dId.value, dPwd: dPwd.value},
        success: function(res){
          if(res.msg == "success"){
            alert("로그인 되었습니다.");
            location.href="/main";
          }
        }


      })
    });
