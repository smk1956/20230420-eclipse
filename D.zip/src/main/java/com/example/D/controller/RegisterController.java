package com.example.D.controller;

import com.example.D.dto.DDto;
import com.example.D.mapper.DMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
public class RegisterController {

    @Autowired
    private DMapper dMapper;

    @GetMapping("/register")
    public String getRegister(){
        return "/register/register";
    }

    @PostMapping("/register")
    @ResponseBody
    public Map<String, Object> saveRegister(@ModelAttribute DDto dDto) {
        dMapper.getRegister(dDto);
        Map<String, Object> map = new HashMap<>();
        map.put("msg", "success");
        return map;
    }
}
