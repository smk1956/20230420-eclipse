package com.example.D.controller;

import com.example.D.dto.EmployeesDto;
import com.example.D.mapper.RegisterMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
public class RegisterController {

    @Autowired
    private RegisterMapper registerMapper;

    @GetMapping("/register")
    public String getRegister(){
        return "/register/register";
    }

    @PostMapping("/register")
    @ResponseBody
    public Map<String, Object> saveRegister(@ModelAttribute EmployeesDto dDto) {
        registerMapper.getRegister(dDto);
        Map<String, Object> map = new HashMap<>();
        map.put("msg", "success");
        return map;
    }
    @PostMapping("/main/emailCheck")
    @ResponseBody
    public int emailCheck(@RequestParam String email) {
        return registerMapper.emailCheck(email);
    }
}
