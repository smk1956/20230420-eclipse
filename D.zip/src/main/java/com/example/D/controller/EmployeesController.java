package com.example.D.controller;

import com.example.D.dto.EmployeesDto;
import com.example.D.mapper.EmployeesMapper;
import com.example.D.mapper.LevelMapper;
import com.example.D.mapper.RegisterMapper;
import com.example.D.service.PagingSrv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

@Controller
public class EmployeesController {

    @Autowired
    private EmployeesMapper employeesMapper;

    @Autowired
    private PagingSrv pagingSrv;

    @Autowired
    private LevelMapper levelMapper;

    @Autowired
    private RegisterMapper registerMapper;


    @GetMapping("/admin/employees")
    public String getEmployees(Model model, @RequestParam(defaultValue = "1", value="page") int page ){
        model.addAttribute("level", employeesMapper.getLevel());
        model.addAttribute("emp", pagingSrv.getPagingEmp(page));
        model.addAttribute("pagination", pagingSrv.pageCalc(page));
        return "/admin/employees";
    }

    @GetMapping("/admin/employees/view")
    public String getEmpView(@RequestParam int dVal, Model model) {
        if( dVal > 0 ) {
            model.addAttribute("emp", employeesMapper.getEmpView(dVal));
            model.addAttribute("level", levelMapper.getLevel());
        }
        return "/admin/employeesView";
    }

    @GetMapping("/admin/employees/delete")
    @ResponseBody
    public Map<String, Object> deleteEmp(@RequestParam int dVal) {
        Map<String, Object> map = new HashMap<>();
        if (dVal > 0) {
            employeesMapper.deleteEmp(dVal); //db
            map.put("msg", "success");
        }
        return map;
    }

    @GetMapping("/admin/employees/updateLevel")
    @ResponseBody
    public Map<String, Object> updateLevel(@ModelAttribute EmployeesDto employeeDto) {
        Map<String, Object> map = new HashMap<>();

        if(employeeDto.getDVal() > 0 && employeeDto.getDLevel() > 0) {
            //update query
            employeesMapper.updateLevel(employeeDto);
            map.put("msg", "success");
        }
        return map;
    }

    @GetMapping("/admin/employees/update")
    public String getEmpUpdate(@RequestParam int dVal, Model model) {
        model.addAttribute("emp", employeesMapper.getEmpView(dVal));
        model.addAttribute("dept", registerMapper.getDept());
        model.addAttribute("level", employeesMapper.getLevel());
        return "/admin/employeesEdit";
    }

    @PostMapping("/admin/employees/update")
    @ResponseBody
    public Map<String, Object> setEmpUpdate(@ModelAttribute EmployeesDto employeeDto) {
        Map<String, Object> map = new HashMap<>();

        if( employeeDto.getDVal() > 0) {
            employeesMapper.setEmpUpdate(employeeDto);
            map.put("msg", "success");
        }

        return map;
    }
}
