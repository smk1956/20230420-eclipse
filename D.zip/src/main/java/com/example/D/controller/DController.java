package com.example.D.controller;

import com.example.D.dto.DDto;
import com.example.D.mapper.DMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
public class DController {

    @Autowired
    private DMapper dMapper;

    @GetMapping("/register")
    public String getRegister(){
        return "/register/register";
    }

    @GetMapping("/login")
    public String getLogin(){
        return "/login/login";
    }

    @GetMapping("/main")
    public String getMain(){ return "/main/main"; }

    @PostMapping("/register")
    @ResponseBody
    public Map<String, Object> saveRegister(@ModelAttribute DDto dDto) {
        dMapper.getRegister(dDto);
        Map<String, Object> map = new HashMap<>();
        map.put("msg", "success");
        return map;
    }

    @PostMapping("/login")
    @ResponseBody
    public Map<String, Object> setLogin(
            @ModelAttribute DDto dDto, HttpServletRequest req){

        int result = dMapper.checkLogin(dDto);

        if(result > 0) {
            //회원가입 된사람이면 session 생성
            HttpSession hs = req.getSession();
            hs.setAttribute("user", dDto);
            hs.setMaxInactiveInterval(60 * 30);
        }

        return Map.of("msg", "success");
    }

    @GetMapping("/admin")
    public String getAdmin(){
        return "/admin/admin";
    }
}
