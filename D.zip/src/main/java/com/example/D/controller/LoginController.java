package com.example.D.controller;

import com.example.D.dto.DDto;
import com.example.D.mapper.DMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@Controller
public class LoginController {

    @Autowired
    private DMapper dMapper;

    @GetMapping("/login")
    public String getLogin(){
        return "/login/login";
    }

    @PostMapping("/login")
    @ResponseBody
    public Map<String, Object> setLogin(
            @ModelAttribute DDto dDto, HttpServletRequest req){

        DDto d = dMapper.checkLogin(dDto);

        if( d != null ){
            if(d.getDAuth().equals("Y")){
                System.out.println("관리자 페이지로 이동");

                HttpSession hs = req.getSession();
                hs.setAttribute("user", d);
                hs.setMaxInactiveInterval(60 * 30);

                return Map.of("msg", "adminsuccess");
            }else {
                System.out.println("사용자 페이지로 이동");
                return Map.of("msg", "success");
            }
        }else {
            System.out.println("이메일 또는 비밀번호를 확인하세요.");
            return  Map.of("msg", "fail");
        }

    }


    @PostMapping("/logout")
    public String getLogout(HttpSession hs){
        hs.invalidate();
        return"/login/login";
    }


}
