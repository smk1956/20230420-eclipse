package com.example.D.dto;

import lombok.Data;

@Data
public class DeptDto {
    private String groupDDeptCode;
    private String groupDDeptName;
    private int groupDPosCnt;
}
