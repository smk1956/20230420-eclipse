package com.example.D.dto;

import lombok.Data;

@Data
public class LevelDto {
    private int groupDLevelCode;
    private String groupDLevelName;
}
