package com.example.D.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EmployeesDto {
    private int dVal;
    private String dId;
    private String dPwd;
    private String dName;
    private String dEmail;
    private String dDept;
    private String dPos;
    private int dLevel;
    private String dAuth;
    private LocalDateTime dCreated;
    private LocalDateTime dModified;
}
