package com.example.D.dto;

import lombok.Data;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class DDto {
    private int dVal;
    private String dId;
    private String dPwd;
    private String dName;
    private String dEmail;
    private String dAuth;
    private LocalDateTime dCreated;
    private LocalDateTime dModified;
}
