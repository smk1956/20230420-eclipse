package com.example.D.mapper;

import com.example.D.dto.LevelDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface LevelMapper {
    @Select("SELECT * FROM group_d_level ORDER BY group_d_level_code ASC")
    List<LevelDto> getLevel();
}
