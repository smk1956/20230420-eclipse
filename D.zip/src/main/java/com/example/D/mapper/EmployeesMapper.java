package com.example.D.mapper;

import com.example.D.dto.EmployeesDto;
import com.example.D.dto.LevelDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

@Mapper
public interface EmployeesMapper {

    @Select("SELECT * FROM group_d ORDER BY d_id DESC LIMIT #{start}, #{limit} ")
    List<EmployeesDto> getEmpList(Map<String, Object> map);


    @Select("SELECT * FROM group_d")
    List<EmployeesDto> getEmp();

    @Select("SELECT COUNT(*) FROM group_d")
    int getTotalCount();

    @Select("SELECT * FROM group_d_level")
    List<LevelDto> getLevel();

    @Select("SELECT * FROM group_d_dept D INNER JOIN group_d E ON\n" +
            "D.group_d_dept_code = E.d_dept INNER JOIN group_d_pos P ON\n" +
            "E.d_pos = P.group_d_pos_code WHERE E.d_val = #{dVal}")
    EmployeesDto getEmpView(int dVal);
    @Delete("DELETE FROM group_d WHERE d_val = #{dVal}")
    void deleteEmp(int dVal);

    @Update("UPDATE group_d SET d_level = #{dLevel} WHERE d_val = #{dVal}")
    void updateLevel(EmployeesDto employeeDto);

    @Update("UPDATE group_d SET " +
            "d_email = #{dEmail}, " +
            "d_name = #{dName}, " +
            "d_passwd=#{dPwd}, " +
            "d_dept = #{dDept}, " +
            "d_pos = #{dPos}, d_level = #{dLevel}, " +
            "d_modified = NOW() WHERE d_val = #{dVal}")
    void setEmpUpdate(EmployeesDto employeeDto);
}
