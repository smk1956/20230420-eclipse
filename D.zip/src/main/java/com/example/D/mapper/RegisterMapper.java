package com.example.D.mapper;

import com.example.D.dto.DeptDto;
import com.example.D.dto.EmployeesDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RegisterMapper {
    @Select("INSERT INTO group_d VALUES(NULL, #{dId}, #{dPwd}, #{dName}, #{dEmail},'100','101', 1,'N', now(), now())")
    void getRegister(EmployeesDto dDto);

    @Select("SELECT COUNT(*) FROM kor_employees WHERE kor_emp_email = #{email}")
    int emailCheck(String email);

    @Select("SELECT * FROM group_d_dept ORDER BY group_d_dept_code DESC")
    List<DeptDto> getDept();
}
