package com.example.D.mapper;


import com.example.D.dto.EmployeesDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface LoginMapper {
    @Select("SELECT * FROM group_d WHERE d_id = #{dId} AND d_passwd = #{dPwd}")
    EmployeesDto checkLogin(EmployeesDto dDto);
}
