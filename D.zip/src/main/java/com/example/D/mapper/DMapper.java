package com.example.D.mapper;

import com.example.D.dto.DDto;
import lombok.Data;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface DMapper {

    @Select("INSERT INTO group_d VALUES(NULL, #{dId}, #{dPwd}, #{dName}, #{dEmail})")
    void getRegister(DDto dDto);

    @Select("SELECT COUNT(*) FROM group_d WHERE d_id = #{dId} AND d_pwd = #{dPwd}")
    int checkLogin(DDto dDto);
}
